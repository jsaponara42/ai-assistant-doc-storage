## Summary

Instead of exporting individual chat transcripts, create a scheduled daily summary of all Claude work done that day. Store these in a dedicated folder so AI agents can load recent context without reading raw transcripts.

## Context

Captured as a quick voice note. The core problem: Claude has no memory between sessions, so context gets rebuilt from scratch. A daily summary log would bridge that gap efficiently.

## Content

### Proposed approach

1. At end of day (or on a schedule), export or summarize all Claude chats from that day
2. Distill into a single daily summary note: what was worked on, decisions made, open items
3. Store in a dedicated folder (e.g., `personal/daily-summaries/` or `business/daily-summaries/`)
4. AI agents load the last 5–7 daily summaries at session start for working memory

### Open questions

- How to trigger the export — manual, Zapier, scheduled script?
- Should summaries be per-project or consolidated?
- What's the right level of detail vs. file size?

## Next steps

- Define the daily summary format/template
- Decide on folder placement and naming convention
- Explore whether Claude.ai has any export automation hooks
