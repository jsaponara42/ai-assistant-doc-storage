# Ruthless For Good — Project Learnings

Running notes on what's working and what isn't across this engagement, unstructured, no format required. Newest entries on top. This exists so the next project starts a little smarter than this one did, not to track deliverables, that lives elsewhere.

Loose prompts if it helps to get started, not a template to fill in order: What surprised you? What took longer than it should have? What would you do differently starting over? What worked better than expected?

---

### 2026-08-18

*(open for your notes)*
