# Maycomb Capital — Upsell Pricing & Pitch Prep

## Summary
Four upsell tracks, priced against Blue Tusk's existing pricing guide and the Cause Crazy comp, with a pitch built from Maycomb's own words rather than a generic sales case. Ranked by likelihood to land given who's actually in the room right now.

## Context
The free diagnostic phase is done. Four SOPs, a workflow map, an AI Playbook, and a written roadmap are already delivered. [[20260707_Maycomb_Capital_AI_Roadmap_Client]]'s "What's Next" section already names four open problems in the client's own language, that section is the natural bridge into this pitch. Pricing below is calibrated against `2 - Pricing Guide` (Blue Tusk's standard rate card) and the Cause Crazy SOW (closest real comp: small team, bounded no-code-adjacent automations, audit-plus-build structure), adjusted for Maycomb's size (12 people), the sensitivity of the data (fund financials, investor reporting), and the fact that the discovery phase here was free, not paid, so there's no audit fee to anchor against.

One thing to flag before pricing: **Andi Phillips (Managing Partner) approves all budgets**, per the Budgeting SOP. Martina and Barry are your contacts, but neither has been confirmed as having spending authority. That materially changes which asks are easy yeses right now versus which need Andi in the room.

**Update, July 14, 2026 call:** the final readout is now set for the week of August 3. Martina raised Andi herself, unprompted, as a possible attendee, before JC needed to make that case, along with Varenka. Worth confirming both actually make the confirmed list once it's finalized (see discovery brief), but the hard part of this ask already happened organically.

---

## The Four Tracks

### Track D — AI / Claude Steward (Retainer)
**What it is:** Ongoing oversight of the Claude rollout, monitoring the Slack gripe channel, building training resources as new hires onboard, curating the SKILLS library, attending the existing bi-weekly Roadmap Meeting for a monthly review.

**Price:** $750–$1,200/month. Blue Tusk's standard advisory rate ($2,500/month) is calibrated for 50–300 person orgs; a 12-person team generates a fraction of that usage volume and gripe-channel traffic, so this is priced down accordingly. Month-to-month, cancel anytime.

**The undeniable hook, updated after the July 14, 2026 call:** this got easier to pitch, not harder. On that call, Martina self-appointed as the AI/automation owner going forward, unprompted, calling herself "the bridge," with Danielle and Barry both agreeing. That's real buy-in already secured. But owning the role on paper and actually running the Slack monitoring, the training builds, the steering-committee-style oversight of the prompt library, on top of everything else she's holding as interim COO, are two different things. The ask isn't "someone should own this" anymore, it's "we know you already own this, let us help you do it without it eating your week."

**Why it lands:** Low dollar amount. Recurring, cancel-anytime framing lowers the bar for a yes. Directly serves Martina's own stated values (systems, structure, accountability) from her *Scale with Purpose* background, and now also her own stated commitment from the call itself. Doesn't require Andi's sign-off for most orgs this size, worth confirming, but a sub-$1,500/month recurring vendor cost is unlikely to need Managing Partner approval the way a five-figure project would.

---

### Track A — Quick Wins Implementation
**What it is:** Build the three automations already scoped and impact-estimated in the roadmap: eliminate duplicate invoice tracking with LeverPoint, automate AP expense categorization, auto-draft quarterly borrower invoices.

**Price:** $4,500–$6,500 fixed fee for the bundle, or $1,500–$2,000 per automation à la carte. Cause Crazy paid $3,500 total for a comparable bundle of three no-code automations; this sits higher because Maycomb's builds touch financial data, need LLM-assisted logic (not pure Zapier triggers), and require LeverPoint coordination on at least two of the three.

**Payment structure:** 50% upfront, 50% on delivery, mirroring Blue Tusk's standard deposit structure.

**The undeniable hook:** Every one of these is tied to a departure. The shared mailbox eases Varenka's handoff. The categorization automation removes a dependency on Danielle's memory, and she's already half-gone. The invoicing automation removes the most time-consuming manual step in a process about to lose its owner. None of this is hypothetical ROI, it's "the person who does this by hand is leaving in weeks."

**Why it lands:** Bounded scope, fixed price, tangible before/after. Easier to say yes to a $5K fixed project than an open-ended retainer. Best pitched as urgent given the transition timeline, not as a nice-to-have.

**Discretionary option:** The SOW allows Blue Tusk to build one small quick win for free, at its discretion, as a no-charge goodwill gesture. If you want a free trust-builder before asking for money on anything else, this is the lever, offer the smallest one (mailbox) free, price the other two.

---

### Track C — Value Driver Discovery (Phase 3)
**What it is:** The deep-dive discovery Ariella's own conversation opened up, deal sourcing and diligence, investor relations and capital raising, borrower asset management, outcome data and impact reporting, mapped the same way the back office was mapped, but this time as a paid engagement.

**Price:** $2,500–$3,000/month for an initial 2–3 month discovery phase, converting into scoped build SOWs once specific opportunities are validated. Not a fixed fee, the scope genuinely isn't known yet, and pricing it as fixed would be dishonest.

**The undeniable hook:** Ariella said it herself, on the record: the impact report is *"such a difficult process"* that *"doesn't need to be"* that hard. That's not Blue Tusk's read on the business, it's the client's own words about their own pain, already captured in the discovery brief. Pair it with the new Investor Relations hire starting August 3, who inherits this process cold and would benefit from having it already mapped before he arrives.

**Why it's a slower close:** This is the highest long-term value track and the least defined. It touches revenue-critical processes the deal team owns, not just Martina's operational scope, and it's priced as a retainer with unknown total cost, which is a harder ask mid-transition. Best pitched as "let's put this on the calendar," not closed today.

---

### Track B — Strategic Investments
**What it is:** The four larger back-office builds: legal bill allocation, full cross-entity AP allocation, the budget variance flagging and recommendation engine, and outcome-data intake for the annual impact report.

**Price:** $10,000–$15,000 total, structured as a 2–3 month project at $3,500–$5,000/month, or priced per-build if Maycomb wants to pick and choose ($3,000–$5,000 each, budget variance engine at the top of that range given its complexity).

**The undeniable hook:** Ariella named the exact outcome she wanted, unprompted: compress the quarterly budget review to *"a single approval meeting."* That's about as close to a client writing your pitch for you as it gets.

**Why it's the slowest close right now:** This is the biggest dollar ask, requires sustained LeverPoint coordination, and lands exactly when nobody wants to make a five-figure financial commitment mid-transition, with no permanent Director of Finance & Ops yet in place to own it. Andi's approval is close to certain to be required here. **Recommend holding this track until the Director of Finance & Ops is hired**, then pitching it directly to them as the new process owner, rather than asking Martina to champion someone else's future budget line.

---

### Track E — Portfolio Company Referral Pipeline (not Maycomb revenue)

**What it is:** Ariella raised this herself, unprompted, on the original June 16, 2026 kickoff call: since Danielle's SOP work was already happening as she prepared to leave, and some portfolio companies likely have similar operational pain, Ariella floated introducing Blue Tusk to portfolio companies that are struggling. Her exact words left it deliberately open, not committed: *"we can have more conversations about whether or not it makes sense to be introduced to portfolio companies and how that might work."*

**Why this isn't like the other four tracks:** No revenue from Maycomb here. Any paid work would be a new, separate engagement directly with the portfolio company. This is a referral channel, not an upsell.

**What's changed since she said it:** Ariella's gone. Martina, the current primary contact, wasn't in that room and has no reason to know this was ever discussed. Treat it as needing to be reintroduced, not as something still live.

**Two conditions Ariella put on it herself, worth respecting:**
1. Scoped to companies that are *struggling*, not a blanket intro across the whole portfolio.
2. Maycomb cares openly about confidentiality (came up on the same call, re: the MSA). Any introduction needs Maycomb's active blessing per company, not a standing open door Blue Tusk works independently.

**The smooth way in:** Don't pitch this as its own ask in the upsell conversation, it'll read as padding. It surfaces naturally as a byproduct of Track C, specifically VD-2 (borrower asset management). If that discovery work maps which portfolio companies are struggling operationally, that's the exact moment Ariella herself described as the right one for an introduction. Let the work create the opening rather than asking for it upfront.

**If it's worth a light mention sooner:** One low-pressure line is enough, something like: *"Early on, Ariella mentioned that if we ever came across portfolio companies that seemed to be struggling with similar things, an introduction might make sense. Just flagging that's still on the table whenever it's useful, no rush."* That reopens the door without asking for anything now.

---

## Likelihood to Land, Ranked

1. **Track D (Steward)** — lowest dollar amount, directly answers a named gap, natural fit for Martina, likely doesn't need Andi.
2. **Track A (Quick Wins)** — bounded, fixed price, urgency is real and visible, easy yes even mid-transition.
3. **Track C (Value Drivers)** — highest ceiling, but slower, plant the seed now, expect to close later.
4. **Track B (Strategic Investments)** — hold. Revisit once the Director of Finance & Ops is hired.

Track E doesn't compete with the above for Maycomb's budget, since nothing is billed to them. It isn't a standalone pitch, it resurfaces on its own once Track C work is underway.

---

## How to Open the Conversation

Don't build a new pitch deck. The client doc already ends on this exact bridge, the "What's Next" section names four problems and gestures at solutions. Walk Martina and Barry through that section live, then get specific with pricing only once they're nodding at the problems. The document did the persuading already; this conversation is just putting numbers on what they already agreed was missing.

Suggested order: open with Track D (cheapest, most obviously needed), confirm it, then move to Track A (tangible, urgent), then mention Track C as "the bigger opportunity, let's revisit once you're settled in." Leave Track B unsaid unless they ask.

## Strategy Decision — Bundled Small Now, Seed Big, Hold the Rest

Weighed going small (protect the relationship, close what's easily closable) against going big (try to capture the full four-track value while attention and goodwill are high). **Decision: go bundled-small now, not big.** Two structural facts drive this, independent of how strong the value case is:

1. **No confirmed spending authority in the room yet.** Andi Phillips approves budgets per the Budgeting SOP; Martina and Barry haven't been confirmed as having spending authority themselves. A big ask (Track C priced, or Track B at all) without Andi actually present and engaged means asking Martina to sell internally on our behalf, to someone she doesn't have a track record with either — high stall risk.
2. **The org can't fully digest a big ask right now.** Interim COO, two departures mid-flight, no permanent Director of Finance & Ops, a brand-new IR hire starting the same week as this readout. A large ask doesn't fail because it's wrong here, it fails because it stalls, and a stalled big ask costs more goodwill than a closed small one.

There's also a sequencing risk specific to this moment: this is the first time money enters the relationship after a genuinely generous free engagement. A first ask that feels disproportionate to what's been delivered risks recoloring the free work as a loss-leader pitch rather than the good-faith diagnostic it was. Right-sizing the first ask protects that.

**So: close Track D + Track A together as one bundled motion, seed Track C for a calendared follow-up (don't price it today), hold Track B entirely unless asked, leave Track E out.** If Andi is confirmed and actively engaged in the room, that's the live signal to expand past the bundle — see the contingency note in the talk track below. Don't pre-commit to small if the room turns out to support more; just don't assume it will.

---

## Pricing One-Pager — What to Bring to the Room

*Internal reference for the August 3 conversation, not a client-facing document. Numbers pull directly from the four tracks above.*

| Track | What it is | Price | Ask today? |
|---|---|---|---|
| **D — AI/Claude Steward** | Ongoing Slack gripe-list monitoring, training resources, SKILLS curation, monthly review at the existing bi-weekly Roadmap Meeting | **$750–$1,200/month**, month-to-month, cancel anytime | **Yes — open with this** |
| **A — Quick Wins bundle** | Shared mailbox (stop double-tracking invoices), AP expense auto-categorization, auto-drafted quarterly borrower invoices | **$4,500–$6,500 fixed** (or $1,500–$2,000/each à la carte), 50% upfront / 50% on delivery | **Yes — pitch right after D** |
| *Optional trust-builder* | Shared mailbox automation only, offered free per SOW discretion | **$0** | *Your call — use if you want a goodwill opener before any pricing* |
| **C — Value Driver Discovery** | Deal sourcing/diligence, investor relations, borrower asset management, outcome-data mapping | **$2,500–$3,000/month**, 2–3 month discovery phase | **No — seed only, get a calendar date, not a price** |
| **B — Strategic Investments** | Legal bill allocation, cross-entity AP allocation, budget variance engine, outcome-data intake | **$10,000–$15,000 total** (or $3,000–$5,000/build à la carte) | **No — hold until Director of Finance & Ops is hired** |

**If landed as bundled (D + A), year-one value:** roughly **$5,250–$7,700** in combined recurring + fixed commitment, likely without needing Andi's sign-off at all given the sub-$1,500/month and bounded-fixed-fee thresholds.

---

## Talk Track — August 3 Readout

**Attendees to plan around:** Martina (confirmed), Barry (confirmed), Danielle (confirmed, transitional), Andi and Varenka (raised as possible adds by Martina herself — confirm before the call whether either actually made the final list).

**1. Open on the document, not a new pitch.** Walk through the Roadmap's "What's Next" section live — it already names four problems in Maycomb's own language. Let them nod at the problems before any number comes up. *"Everything in this section is stuff your own team told us — we didn't invent these four gaps."*

**2. Quick read on the room before pricing anything.** If Andi is present, a natural, non-awkward way to surface budget process without asking for money yet: *"Before we get into numbers — is this a Martina-level decision, or does it need to run through you, Andi?"* Answer shapes how far to go today.

**3. Open with Track D.** Cheapest, most obviously needed, and it's Martina's own language to borrow: *"You called yourself the bridge on our last call — this is us helping you actually run that role without it eating your week."* Confirm this one before moving on.

**4. Move to Track A.** Tangible, bounded, urgent. Anchor each automation to the departure it eases: *"The mailbox helps Varenka's handoff. The categorization piece removes a dependency on Danielle's memory, and she's already half-gone. None of this is hypothetical ROI — it's 'the person who does this by hand is leaving in weeks.'"* If using the free mailbox offer, lead with it here as the goodwill opener, then price the other two.

**5. Mention Track C, but don't price it.** *"There's a bigger opportunity in the stuff that actually drives revenue and mission — deal sourcing, investor relations, the impact report Ariella herself called 'such a difficult process' that 'doesn't need to be' that hard. Your new IR hire starts the same week as this call and inherits that process cold. We'd love to map it before he's in the seat, but let's put time on the calendar for that rather than scope it today."* Goal: a scheduled follow-up, not a close.

**6. Leave Track B unsaid.** Only surface pricing if directly asked. If asked, give the range but recommend waiting: *"Once the Director of Finance & Ops is hired, this is the natural thing to scope with them directly, since they're the one who'll own it going forward."*

**7. Close soft on Track E if it fits naturally.** Only if the conversation organically touches borrower support or portfolio companies — don't force it. *"Early on, Ariella mentioned that if we ever came across portfolio companies struggling with similar things, an introduction might make sense. Just flagging that's still on the table whenever it's useful, no rush."*

---

## Next Steps
- Confirm Martina's actual spending authority before pitching anything above ~$1,500/month.
- Decide whether to offer the mailbox quick win free (discretionary, per SOW) as a trust-builder ahead of this conversation.
- Draft the actual pricing one-pager or proposal once JC confirms these ranges.
- Hold Track E out of this pitch entirely. Revisit once Track C discovery is underway and a struggling portfolio company actually surfaces.
