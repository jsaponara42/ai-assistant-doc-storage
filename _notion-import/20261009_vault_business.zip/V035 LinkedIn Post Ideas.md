## Summary
Evergreen tracker for LinkedIn post ideas. Each idea links to a stub or draft in `writing/`. Posts draw from JC's experience in AI/automation — both as Director of Product & Innovation at Maslansky + Partners (agency context, Omnicom ecosystem) and as a consultant at Blue Tusk. Framed broadly for a professional audience, relevant to anyone running operations, teams, or client work.

## Categories

| Category | Description |
|---|---|
| `reaction` | React to a specific news article, tool release, or AI/automation update — link the source |
| `hot-take` | Dramatic, contrarian opinion that goes against conventional thinking in the space |
| `story` | Personal experience, specific moment, or behind-the-scenes window into JC's work |
| `how-to` | Practical tip or mini-tutorial |
| `case-study` | Anonymized win or lesson from a client or project |
| `group-engagement` | Conversation-starter posts designed for industry groups (PI law, legal ops, agency ops, etc.) |

---

## Post ideas

### Reaction
> Format: find the article/release → summarize it in one sentence → give your take in 2–3 sentences → tag or link the source

- [ ] [[business/marketing/writing/post-react-openai-operator|React to OpenAI Operator (or similar agentic AI release)]] — "This just dropped and it changes how I think about [X workflow]" — pick a specific capability, make it concrete for a business operator audience
- [ ] [[business/marketing/writing/post-react-new-zapier-ai|React to a new Zapier AI or Make.com feature drop]] — these ship constantly; pick one with direct implications for intake, follow-up, or document handling
- [ ] [[business/marketing/writing/post-react-google-notebooklm|React to a Google NotebookLM or Gemini update relevant to knowledge work]] — "I tested this on [specific use case] — here's what actually happened"
- [ ] [[business/marketing/writing/post-react-ai-legal-tool|React to a new AI tool built for a specific vertical (legal, comms, agency, etc.)]] — "This is interesting. Here's what it does well and where I'd still use automation instead"
- [ ] [[business/marketing/writing/post-react-benchmark-or-study|React to a benchmark, study, or stat about AI adoption in professional services]] — anchor to a real number, give your interpretation, invite disagreement
- [ ] [[React to "Corporate Claws" article]] - [[2026-03-31-corporate-claws-strategy]]

### Hot take
> Should feel slightly uncomfortable to post. If it doesn't create some tension, it's not a hot take.

- [x] [[business/marketing/writing/post-ht-real-ai-is-boring|"Real AI in business is boring — and that's how you know it's working"]] — the glamorous demos are not what's running in production; the stuff that actually sticks is unglamorous, repetitive, and invisible
- [ ] [[business/marketing/writing/post-ht-local-ai-reality|"The Local AI Reality Check"]] — running AI locally costs significant money upfront vs. per-token or subscription; for most people, cloud services are better, more capable, and more user friendly. Local AI is a hobby for those with patience and a knack for tinkering.
- [ ] [[business/marketing/writing/post-ht-real-automation-is-boring|"Real automation in business is boring. Stop watching the highlight reel."]] — viral automation demos show the 1%; the other 99% is moving a field from one spreadsheet to another, and that's fine
- [ ] [[business/marketing/writing/post-ht-you-need-a-product-first|"You don't have an AI product. You have a product with AI in it — maybe."]] — most orgs bolt AI onto a process that was never designed to receive it; the product has to exist and be understood before AI adds value
- [ ] [[business/marketing/writing/post-ht-coo-before-automation|"You need someone who thinks like a COO before you can automate anything meaningful"]] — automation exposes every gap in your operations; without a process-minded owner, you're just building technical debt faster
- [ ] [[business/marketing/writing/post-ht-ai-wont-save-bad-process|"AI won't save your org. It'll just make your bad process faster."]] — firms and agencies buying AI tools without fixing workflow first are accelerating their own dysfunction
- [ ] [[business/marketing/writing/post-ht-unified-agent-systems|"The End of Individual Automations"]] — building automations one by one is fading; the next era is unified agent operating systems where context flows between tools. The most important thing is getting all your project data, people, and information into a machine-readable format.
- [ ] [[business/marketing/writing/post-ht-automation-consultants-lie|"Most automation consultants are lying to you — including the ones who don't know it"]] — the industry defaults to selling complexity; simple solutions get dismissed because they're not billable enough
- [x] [[business/marketing/writing/post-ht-linkedin-one-subscription|"LinkedIn tricks you into thinking you need more than one AI subscription"]] — multi-tool posts are creator-to-creator content dressed as advice; pick one and use it well
- [ ] [[business/marketing/writing/post-ht-machine-readability|"Machine Readability Is Non-Negotiable"]] — if your tools, data, and workflows aren't AI-readable through APIs, CLIs, or proper tooling, you'll get left behind. This isn't optional anymore — it's infrastructure.

### Story
> Specific, concrete, first-person. The more specific the detail, the more it lands. Draw from M+P, Omnicom, and Blue Tusk.

- [x] [[business/marketing/writing/post-story-voice-notes-ai|"I use voice notes to make my AI use feel way more natural"]] — how dictating to a notes app and then asking Claude to read it and take action changed the quality and speed of JC's AI interactions; this feels like a personal assistant
- [x] [[business/marketing/writing/post-story-ai-workflow-stack|"My AI workflow stack: Claude, Obsidian, a local MCP server, and git"]] — specific breakdown of the setup: voice notes or chat → Claude → local MCP writes to markdown files in an Obsidian vault → git keeps it synced; why this over Claude Code; the philosophy of owning your own context layer
- [ ] [[business/marketing/writing/post-story-iteration-not-plug-and-play|"Everyone thinks AI is plug and play. Here's how many iterations it actually took."]] — walk through a real build at M+P or Blue Tusk; show the testing, the dead ends, the socialization process inside a real org
- [x] [[business/marketing/writing/post-story-what-sops-taught-me|"I didn't understand SOPs until I had to automate without one"]] — what writing and enforcing SOPs at M+P taught JC about process discipline, and why they're load-bearing for any automation that lasts
- [ ] [[business/marketing/writing/post-story-interns-and-data-wrangling|"The most valuable thing I ever used an intern for had nothing to do with AI"]] — in established orgs, the unlock is data cleanup and wrangling that only humans can do; AI is downstream of that; story from M+P
- [ ] [[business/marketing/writing/post-story-innovating-in-a-big-org|"What it's actually like to build new things inside a large agency"]] — the Omnicom context: navigating approvals, stakeholders, existing tools, and inertia while trying to ship something new
- [ ] [[business/marketing/writing/post-story-first-automation-win|"The first automation I built at work that actually saved someone real time"]] — specific, concrete, outcome-first — no buzzwords
- [ ] [[business/marketing/writing/post-story-moment-i-got-it|"The moment I understood what automation was actually for"]] — a specific before/after realization, not a general statement about AI
- [ ] [[business/marketing/writing/post-story-client-skeptic|"The most skeptical person in the room ended up being the one who got it fastest"]] — story about a reluctant stakeholder who became the internal champion
- [x] [[business/marketing/writing/post-story-mistake-i-made|"I automated the wrong thing first — and it cost me two weeks"]] — vulnerability post; shows process thinking, not just wins
- [ ] [[business/marketing/writing/post-story-what-i-learned-discovery|"What I've learned from doing discovery with teams that think they don't need automation"]] — pattern recognition from real conversations, anonymized
- [ ] [[business/marketing/writing/post-story-weekend-project|"I spent a Saturday morning solving a problem that was taking someone 3 hours a week"]] — shows what's possible at low effort; builds intrigue without overselling
- [x] [[business/marketing/writing/post-instagram-content-strategy|"My modular Instagram content strategy"]] — three-pass filming (hooks, middles, CTAs) + AI stitching tool = hundreds of variations from one session
- [ ] [[business/marketing/writing/post-story-vibe-coding-pitfalls|"What I learned from vibe coding (and what I built wrong without knowing it)"]] — built something that works on the surface but doesn't scale; discovered backend principles the hard way because AI moves fast and you can miss foundational decisions
- [ ] [[business/marketing/writing/post-story-vibe-coding-restart|"Sometimes it's faster to restart than to fix the code you already wrote"]] — when a project changed direction mid-build, rewriting from the right principles beat trying to patch the existing codebase
- [ ] [[business/marketing/writing/post-story-vibe-coding-early-feedback|"Vibe coding lets you get real feedback before you've committed to anything"]] — used to need wireframes and planning to get input; now you can build a working prototype fast enough that stakeholders see something real early, which means better feedback and less rework
- [ ] [[business/marketing/writing/post-story-agent-adoption-via-team|"The AI adoption tactic that actually worked: let the team deliver it"]] — at Maslansky, agent skills delivered by staffers got far more adoption than top-down evangelism; peer-to-peer beats prophet-to-congregation every time
- [ ] [[business/marketing/writing/post-story-scope-creep-vibe-coding|"Vibe coding causes scope creep faster than anything I've ever seen"]] — when people see how quickly you can build, they start asking for everything; the MVP never ships because you keep adding lanes; building fast is only valuable if you stay focused
- [ ] [[business/marketing/writing/post-story-rocky-team-instability|"Our automation project stalled — and it wasn't the automation's fault"]] — team inconsistency broke the process; AI and automation require stable inputs and consistent people; when the team changes, the pieces that make automation work start to break
- [ ] [[business/marketing/writing/post-story-pausing-ambitious-project|"I told a client to pause their automation project. It was the right call."]] — Rocky context: when a client finds a way to be profitable without heavy AI, the right advisor says so; pausing now and returning when the cash flow is proven is better than automating something that hasn't been validated; trust is the long game
- [ ] [[business/marketing/writing/post-story-hallucination-politics|"I got burned by an AI hallucination — and I use AI every single day"]] — lazily asked Claude how many US presidents came from a different party than the previous president (not as VP succession); it said never; that's very wrong; the conversation went sideways and we didn't catch it until later; blind AI confidence may be more dangerous than no confidence at all
- [ ] [[business/marketing/writing/post-story-task-prioritization|"How I prioritize tasks across projects without losing my mind"]] — not tool-specific; organize by task → project → due date; focus on due date so accountability stays consistent regardless of which project it comes from; always moving, always clear on what's next
- [ ] [[business/marketing/writing/post-story-adversarial-analysis|"I built a prompt that attacks my own ideas — and it makes everything better"]] — adversarial analysis skill: feed it an idea, product, piece of marketing; it acts as an adversary and tears apart every assumption; AI defaults to agreement so you have to build in the counterforce
- [ ] [[business/marketing/writing/post-story-getting-into-ai|"People keep asking me how to get into AI. Here's what I actually tell them."]] — "get into AI" is too broad; it's like saying "get into computers" in the '90s; the question is what sector you care about and what companies in that space need non-technical people to do; find the intersection of your background and an AI-forward org, not a career pivot from scratch

### How-to
- [ ] [[business/marketing/writing/post-map-your-workflow|"How to map a broken workflow in 20 minutes (no tools required)"]] — sticky, practical, shareable; positions JC as a process thinker
- [ ] [[business/marketing/writing/post-five-signs-manual-process|"5 signs a manual process is costing you more than you think"]] — diagnostic framing, resonates with ops-minded readers
- [ ] [[business/marketing/writing/post-howto-meeting-to-action|"From Meeting Transcription to Real Action"]] — meeting transcriptions are usually dead ends. With the right file setup, you can go directly from an AI meeting transcription to taking real action on a project.
- [ ] [[business/marketing/writing/post-react-openai-operator|"How I use voice notes and AI to write SOPs fast"]] — SOPs are important, but they can be frustrating to make. There's a way to get a very solid draft done in under an hour.

### Case study
> Anonymized. Draw from M+P, Omnicom, or Blue Tusk client work.

- [ ] [[business/marketing/writing/post-case-intake-bottleneck|"A team was losing leads in the first 24 hours — here's what we fixed"]] — anonymized intake speed story
- [ ] [[business/marketing/writing/post-case-no-show-problem|"No-shows were killing a firm's consultation rate — one automation changed that"]] — anonymized no-show eliminator story
- [ ] [[business/marketing/writing/post-case-agency-data-cleanup|"Before we could build anything smart, we had to make the data dumb-proof"]] — anonymized M+P-era story about data wrangling as a prerequisite to any real automation

### Group engagement
> Posted natively in LinkedIn Groups (PI law, legal ops, law firm management, agency ops, etc.). Short, open-ended, invites strong opinions. Not a broadcast.

- [ ] [[business/marketing/writing/post-ge-how-does-your-firm-handle-intake|"How does your team handle lead or client follow-up after hours? Still manual?"]] — operational question, invites war stories and process sharing
- [ ] [[business/marketing/writing/post-ge-ai-tool-poll|"What AI tool has actually stuck at your org — and what got abandoned after 30 days?"]] — high-engagement; surfaces real adoption data and frustrations
- [ ] [[business/marketing/writing/post-ge-biggest-workflow-bottleneck|"What's the one workflow you'd automate first if you could snap your fingers?"]] — surfaces pain points across industries, builds a prospect list in the comments
- [ ] [[business/marketing/writing/post-ge-ai-adoption-in-big-orgs|"For those working in larger orgs — what's the biggest internal barrier to actually shipping AI tools? Budget, legal, IT, culture?"]] — draws from JC's Omnicom experience; resonates with innovation/ops roles inside enterprise
- [ ] [[business/marketing/writing/post-ge-sop-question|"Does your team run on documented SOPs, vibes, or something in between?"]] — low-stakes, relatable question that opens a conversation about process maturity
- [ ] [[business/marketing/writing/post-ge-intake-speed-benchmark|"How fast does your team typically follow up with a new inquiry? Trying to understand what 'normal' looks like."]] — innocuous framing, benchmarks the exact problem Blue Tusk and JC's work solves

---

## Notes
- Stub files above don't need to exist yet — Obsidian allows forward wikilinks
- When drafting a post, create the file at the linked path with full frontmatter
- Keep posts under 250 words for LinkedIn; lead with a hook, end with a soft CTA or question
- Reaction posts: always find and link a real article before drafting — the source is load-bearing
- Group engagement posts: post natively in the group, not as a share — engagement algorithms favor native posts
- Draw on M+P / Omnicom experience freely — it's credibility, not a conflict
