## Summary
Central hub for Blue Tusk's marketing and thought leadership activities. Covers LinkedIn presence and writing — framed broadly around AI and automation rather than Blue Tusk directly, given JC's full-time employment context.

## Context
JC needs to build a personal brand as an authority in AI/automation to attract PI law firm clients without drawing attention to Blue Tusk specifically. Posts live under JC's personal LinkedIn, not a company page.

## Content

### Active assets
- [[00_linkedin-post-ideas|LinkedIn Post Ideas]] — evergreen tracker with categories and stub links to individual post drafts

### Strategy
- Posts should stay broad: automation, AI, workflow design, legal ops — not Blue Tusk-specific
- Build JC's personal brand first; Blue Tusk is a background signal, not the headline
- Post categories in use: reaction to news, controversial take, personal story, how-to/tip, anonymized case study

## Next steps
- Pick first post draft to write from [[00_linkedin-post-ideas]]
- Publish cadence TBD — start with 1x/week
