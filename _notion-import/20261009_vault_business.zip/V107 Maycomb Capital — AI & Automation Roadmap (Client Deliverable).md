# Maycomb Capital
## AI & Automation Roadmap

**Prepared for Maycomb Capital by Blue Tusk LLC**
**July 2026**

*Practical AI and automation, built around how your business actually works.*

---

## Executive Summary

Over six weeks we documented how Maycomb's back office actually runs, mapped what drives revenue and mission impact, and built a working point of view on where AI fits during your transition.

**What we found:**
- Four core back-office processes, documented for the first time: legal bills, the AP run, quarterly invoicing, and budget-to-actuals.
- Three quick wins, ready to build now, each tied to a departure already underway.
- Three bigger automation opportunities that solve real recurring pain, including the single-approval-meeting goal your own team already named.
- Real, unmapped opportunity in the work that actually drives revenue and mission impact: deal sourcing, investor relations, borrower support, and outcome-data collection.

**What we recommend:** start with the quick wins. They're bounded, low-risk, and solve problems tied directly to people who are currently leaving. Alongside that, a quick audit of how your documents and files are organized today gives us a clear, concrete starting point, on its own, no commitment to anything bigger required. From there, the clearest next step is going deeper on the revenue-driving opportunities above, and putting a steward in place so AI adoption doesn't fragment as your team grows.

Everything below backs this up in detail. If you read nothing else, read "What's Next" at the end.

---

## Where You Stand Today

Maycomb is mid-transition. A new interim COO. A new Director of Finance and Operations on the way. A new Analyst. A brand new Claude rollout, all at once.

That's a lot to hold. It's also exactly when a clear view of what AI can and can't do for you matters most.

We spent the last several weeks inside your operations: working sessions with your team, a full walkthrough of how your core financial processes actually run, and a conversation about what drives value for your business, not just what costs you time.

This document is what we found.

---

## What We Found

Your back office finance runs on four processes: legal bill tracking, the biweekly AP run across four funds and a management company, quarterly borrower invoicing, and budget-to-actuals. All four are now documented for the first time, based on how your team actually works. 

That documentation is worth something on its own. Knowledge that used to live in one or two people's heads is now written down, right as those people are leaving.

We also looked at your tools: Claude, LeverPoint as your fund administrator, Affinity as your new CRM. 

And we looked past the tools, at what actually drives value for Maycomb: how you source deals, how you support borrowers, how you raise and steward investor capital, how you collect and report on outcomes.

Most automation work stops at cost reduction. We didn't stop there.

---

## Vision and Goals for AI at Maycomb

**AI shouldn't replace judgment. It should stop wasting judgment on work that doesn't need it.**

Almost everywhere we looked, the same pattern showed up. Real expertise was going into manual lookups and rebuilding numbers that already existed somewhere else in the system. That's not a skills gap. That's misallocated attention.

Three things are worth building toward:

- **Free up capacity for the work only a person can do.** Every process we looked at has a mechanical core, data entry, lookups, formatting, and a judgment core: does this allocation make sense, is this budget line right. Automation should handle the first. Your team should handle the second.
- **Build resilience, not dependency.** Your current transition is a live example of what happens when process knowledge lives in one or two people. Document and automate the mechanical layer, and the next transition costs you far less.
- **Go beyond the back office.** Most firms stop at cost centers. What sets Maycomb apart, how you source deals, support borrowers, and report on outcomes, deserves the same discipline. It probably matters more.

---

## The Opportunities We See

**At a glance:**

| Type | Opportunity | Why It Matters |
|---|---|---|
| Quick Win | Stop tracking invoices twice | Eases Varenka's handoff into the AP run |
| Quick Win | Automate AP expense categorization | Removes a dependency on Danielle's memory |
| Quick Win | Auto-draft quarterly borrower invoices | Cuts about an hour of manual work to a quick review |
| Bigger Play | Legal bill allocation and reimbursement tracking | Cuts the weekly back-and-forth on judgment calls |
| Bigger Play | Cross-entity AP allocation | Tightens a payment cycle that now runs 3 days to a week |
| Bigger Play | Budget-to-actuals | Turns a multi-day review into one approval meeting |
| Real Opportunity | Deal sourcing, diligence, investor relations, borrower support, outcome data | Where we believe the real opportunity lies, not yet mapped |

### Quick Wins

- **Stop tracking invoices twice.** Right now the same invoice gets tracked by your team and by LeverPoint, then reconciled against itself every two weeks. One shared record fixes that. Expect less reconciliation time and an easier handoff as Varenka takes over the AP run.
- **Stop re-deciding expense categories.** New vendors currently need someone to remember the right category from memory. That shouldn't depend on any one person. Expect fewer corrections with LeverPoint, and less reliance on memory that's leaving with Ariella and Danielle.
- **Cut quarterly invoicing to minutes.** Pulling accrued interest for 15 borrowers from your loan servicing model is the slow part today, not the drafting. Automate the pull. Expect quarterly invoicing to drop from about an hour of manual work to a quick review and send.

None of this requires rethinking how your team works. It reduces time spent, and it reduces dependency on any one person's memory, which matters more than usual right now.

### The Bigger Plays

- **Legal bill allocation and reimbursement tracking.** About half of deal-level bills need a judgment call today. Get that right and you cut the back-and-forth that eats into your week. Expect a cleaner reimbursement trail too.
- **Cross-entity AP allocation.** Your payment cycle now takes three days to a week, depending on how fast approvals move. Expect that to land consistently at the fast end, with the same people approving the same things.
- **Budget-to-actuals.** Your quarterly review is a multi-day, judgment-heavy process today. Your team already named the goal: one approval meeting instead. Expect to get there.

### Where the Real Opportunity Lies

The conversations that surprised us weren't about your back office. They were about deal sourcing, diligence, how you support borrowers after you've invested, how you raise and nurture investor relationships, and how you collect the outcome data behind your annual impact report.

These are the parts of Maycomb that actually drive revenue and mission impact. Most firms never look here. What we heard suggests real opportunity, especially in how outcome data moves from your portfolio companies into your hands each year. Your own team called that process harder than it needs to be.

We haven't mapped these the way we've mapped your back office. That's a bigger project than what we've done so far.

---

## Adoption and Governance

A good process on paper isn't the same as an adopted habit. Claude access alone won't create consistent use across twelve people, especially while you're onboarding new hires. Left alone, usage fragments. A few people get good at it. Most don't. The gap grows the longer it sits unmanaged.

We built practical guidance for your team. Guidance on paper and adoption in practice are two different things.

See: Maycomb AI Playbook

---

## An Ongoing Relationship

Everything here came from real time inside your operations. That's not a snapshot. It's the start of a picture of Maycomb that we keep, and it gets sharper the longer we work together.

That matters practically. Future work starts from what we already know, not a blank page. Less time re-explaining your entity structure, your team, what you've already tried.

---

## What's Next

You now have something most firms in your position don't: a documented back office, a clear set of automation opportunities, and a real point of view on where AI fits at Maycomb.

That work also surfaced problems you didn't have named before. Four of them.

1. **Deal sourcing and capital deployment isn't mapped.** You know it's a value driver. You don't yet know where the friction actually is.
2. **Investor relations and capital raising runs on instinct, not process.** That's fine today. It's difficult to scale past the current team.
3. **Outcome data collection is the most painful process nobody's redesigned.** Your new Investor Relations hire starts August 3 and inherits it as-is.
4. **AI adoption has an owner on paper, not in practice.** Martina and Varenka now hold that role jointly, on top of everything else they're each already carrying. Without someone dedicated to actually running it, usage still fragments the way it always does on a twelve-person team mid-transition.

Here's how we'd tackle each one. For the first three, we'd run the same kind of structured discovery we ran on your back office: working sessions with the right people, mapped into a clear current-state picture, then a prioritized set of opportunities, the way this document was built.

For the fourth, we're proposing something more hands-on: **Blue Tusk as your ongoing AI steward.** Three things, specifically:

- **Solution monitoring.** We keep an eye on where your team could be using AI and automation the most (Slack gripe list addressed in the AI playbook), and catching what's breaking or being ignored before it turns into a pattern nobody addresses.
- **Claude training resources.** Built out as new hires come on board, so adoption doesn't reset every time your team changes.
- **A consistent force.** A clear owner who has Maycomb's best interests in mind for your AI and automation work, a source of decision support for upcoming investments, and someone who pushes the business toward good decisions, not just convenient ones.


That's the difference between a Playbook that gets read once and one that actually holds.

There's also a lower-commitment place to start, independent of any of the above. As agentic AI starts working directly inside your files, not just answering questions you type, but reading and reasoning across what's actually stored, how well those files are organized becomes a real factor in the quality of what you get back. Organized well, AI finds the right document and gives you a reliable answer. Organized poorly, one of two things happens: it can confidently hand you the wrong answer because it searched in the wrong place, or it can spend far more effort finding what it needs than it should, and that adds up in real, avoidable AI cost over time.

That's not a problem today so much as a problem that grows the more you lean on AI going forward, and now, before anything bigger gets built on top of it, is the cheapest time to find out where you actually stand. A quick audit of how your documents and files are organized today, across SharePoint and the systems that feed it, gives both of us a clear, concrete read on that. It's bounded and fast.

We'd like to talk about what this looks like as a next engagement. Let us know when.

**
