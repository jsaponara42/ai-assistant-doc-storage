Placeholder — delete once the first call brief is added to this folder.
