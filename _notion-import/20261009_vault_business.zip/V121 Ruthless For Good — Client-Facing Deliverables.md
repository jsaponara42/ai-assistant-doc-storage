Placeholder — delete once the first client-facing deliverable is added to this folder.
