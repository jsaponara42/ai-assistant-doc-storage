## Summary

Archive of Ellipsis Manual technique attempts older than the last 10. Entries cut from `ellipsis-log-active.md` and pasted here for long-term reference.

---

## Archived Attempts

<!-- Entries pasted from active log once it exceeds 10 attempts -->
